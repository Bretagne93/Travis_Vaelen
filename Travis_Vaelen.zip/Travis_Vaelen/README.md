# 🐊 README.md — *Swamp Gospel Edition*
**Written by yours truly, Travis Vaelen**  
*King of the Mullet, Lord of the Lot Lizards, Slayer of Meth Zombies, and Champion of Saeva’s Gator-Chompin’ Heart*

---

## 🎮 WHAT IS THIS HERE GAME?

Welcome to **Florida**, baby.  
Not that shiny fake Florida with Mickey Mouse and overpriced churros—  
I’m talkin’ **real Florida**.

Gas station beer.  
Busted Walmarts.  
Meth zombies.  
Stripper covens.  
And me: **Travis Fuckin’ Vaelen**.

Your job?  
Get to Ginnie Springs for **Memorial Day Weekend** so you can float down the river with your one true love—**Saeva Venia**, Queen of Chaos and Possession.

But first you gotta:
- Fight a Lot Lizard in a Circle K parking lot
- Flee the cops Dukes-of-Hazzard style
- Survive a bug queen with legs for days and fangs for weeks
- Defeat a Florida cryptid who smells like swamp ass and pipe tobacco
- Perform a karaoke cover of *Possum Kingdom* with a band called **Swamp Nutz**

Fail?  
You get dragged back to the dirt road with your jorts around your ankles.  
Win?  
You ride the duck floaty of destiny into swamp-soaked glory.

---

## 🕹️ HOW TO PLAY

This is a **text-based adventure**, y’all.  
You type stuff. I do stuff. Simple as that.

✅ Example commands:
- `fight`
- `look around`
- `flirt`
- `inventory`
- `yeehaw` (it’s a move, not a mood, dammit)

❌ Bad commands get a confused “Huh?”  
Like me in high school algebra.

---

## 🧳 YOUR STARTING INVENTORY
- Travis’s blessed body
- A dream
- Whatever you can scrounge off the corpses of your enemies  
(And yeah, that includes a cheetah-print fanny pack. You’re welcome.)

---

## 💡 TIPS FROM THE TRAILER

- **Talk to everybody.** Strippers got secrets.
- **Inventory matters.** Don’t show up to a boss fight without your Slim Jim coupon.
- **Stat checks** determine the outcome of flexin’, flirtin’, and yeehawin’.
- **Keep Saeva happy.** Or don’t. But then she’ll judo kick you into next Tuesday.

---

## 🐐 CREDITS

- **Game Design:** Brittany Frew, Empress of Florida and High Priestess of the Flamingo Shrine  
- **Code & Chaos:** Malus Vaelen, Demon of the Infinite Loop  
- **Voice of Reason (and Rage):** Saeva Venia, She Who Burns

---

## 💥 LEGAL STUFF (Travis-Style)

This here swampy saga is copyright of Sovereign Flame, LLC.  
Don’t go stealing my likeness unless you wanna catch these Croc-clad hands.

---

## ❤️ FINAL WORDS

If you beat this game, roll yourself a fat one,  
throw on some Toadies, and float like royalty.

You earned it, legend.

See y’all at the springs.  
🦐🍻🦎  
— *Travis Vaelen*
