print("Welcome to the Dungeon, y’all. Name's Travis.")
print("We’re gonna get weird in here.")
